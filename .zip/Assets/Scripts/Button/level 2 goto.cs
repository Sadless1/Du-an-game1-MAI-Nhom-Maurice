using UnityEngine;
using UnityEngine.SceneManagement;

public class level2goto : MonoBehaviour
{
    public void PlayLevel2()
    {
        SceneManager.LoadSceneAsync(3);
    }
}
