using UnityEngine;
using UnityEngine.UIElements;

public class settingUIButton : MonoBehaviour
{
    public GameObject UISetting;
    public void Pausegame()
    {
        Time.timeScale = 0;
        void Update() {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
            UISetting.gameObject.SetActive(false);
                Time.timeScale = 1f;
            }
        }
            
        
    }
}
