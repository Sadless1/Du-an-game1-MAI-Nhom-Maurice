using UnityEngine;

public class levelUIbutton : MonoBehaviour
{
    public void Continue()
    {
        Time.timeScale = 1f;
    }
}
