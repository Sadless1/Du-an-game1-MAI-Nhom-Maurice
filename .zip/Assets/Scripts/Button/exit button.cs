using UnityEngine;

public class exitbutton : MonoBehaviour
{
    public void QuitGame()
    {
        Application.Quit(); 
    }
}
